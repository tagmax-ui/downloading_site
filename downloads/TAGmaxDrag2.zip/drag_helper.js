document.addEventListener("dragstart", function (event) {
    const selection = window.getSelection();
    const selectedText = selection ? selection.toString() : "";
    if (selectedText) {
        const url = window.location.href;
        const dt = event.dataTransfer;
        dt.setData("text/plain", `${selectedText}\n\n[Source: ${url}]`);
        dt.setData("text/uri-list", url);
        dt.setData("text/html", `<p>${selectedText}<br><small>Source: ${url}</small></p>`);
        console.log("Dragstart ▶️ Texte:", selectedText, " | URL:", url);
    }
});
